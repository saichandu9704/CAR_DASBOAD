
#ifndef ECU1_SENSOR_H
#define	ECU1_SENSOR_H

#include <stdint.h>
#include "keypad.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "clcd.h"

#define MAX_GEAR 7
#define SPEED_ADC_CHANNEL 0x04
#define ENG_TEMP_ADC_CHANNEL 0x06

#define GEAR_UP             MK_SW1
#define GEAR_DOWN           MK_SW2
#define REVERSE             MK_SW3
#define COLLISION           MK_SW10

void main_config(void);
uint16_t get_speed(void);
unsigned char get_gear_pos(void);
uint16_t get_engine_temp(void);

#endif	/* ECU1_SENSOR_H */

