/*
    Project:   CAN Based Automotive Dashboard
 *  Author: 1. Vinod Kumar
 *          2. Yogesh
 *          3. Sai Chandu
 *  Description: Retrieve the values of gear changes, engine temperature, and speed, convert the received
 *              data into string format and transmit it along with specific message IDs�and�a�delay.
*/


#include <xc.h>
#include<stdio.h>
#include "ecu1_sensor.h"

void main_config(void) {
    init_matrix_keypad();
    init_adc();
    init_can();
    init_clcd();
}

extern unsigned char can_payload[13];

unsigned short get_speed(void) {
    uint16_t adc_reg_val = read_adc(SPEED_ADC_CHANNEL);

    return (adc_reg_val / 10.33);

}

unsigned char get_gear_pos(void) {
    static unsigned char gear_pos = 1;

    char key = read_switches(STATE_CHANGE);

    if (key == GEAR_UP) {
        if (gear_pos < MAX_GEAR) {
            gear_pos++;
        }
    } else if (key == GEAR_DOWN) {
        if (gear_pos > 1) {
            gear_pos--;
        }
    } else if (key == REVERSE) {
        if (gear_pos == 1) {
            gear_pos = 0;
        } else if (gear_pos == 0) {
            gear_pos = 1;
        }
    } else if (key == COLLISION) {
        gear_pos = 8;
    }

    return gear_pos;

}

uint16_t get_engine_temp(void) {
    uint16_t adc_reg_val = read_adc(ENG_TEMP_ADC_CHANNEL);

    return ((adc_reg_val * ((float) 5 / 1023))*40);
}

void main() {
    unsigned char gear_pos, speed_arr[2], eng_arr[2];
    unsigned short speed, engine_temp;
    int delay1=100,delay2=200,delay3=300;

    unsigned int delay = 0;

    main_config(); //Configuring the peripherals

    while (1) {

        //Have to get gear position and transmit to ECU3

            gear_pos = get_gear_pos();
            if (!delay1--) {
                can_transmit(GEAR_MSG_ID, &gear_pos, sizeof (gear_pos));
                delay1=100;
            }

            speed = get_speed();

            speed_arr[1] = speed % 10;
            speed_arr[0] = speed / 10;

            if (!delay2--) {
                can_transmit(SPEED_MSG_ID, speed_arr, sizeof (speed_arr));
                delay2=200;
            }

        //Have to get temperature and transmit to ECU3
            engine_temp = get_engine_temp();

            eng_arr[0] = engine_temp / 10;
            eng_arr[1] = engine_temp % 10;
            if (!delay3--) {
                can_transmit(ENG_TEMP_MSG_ID, eng_arr, sizeof (eng_arr));
                delay3=300;
            }
 
    }
}

