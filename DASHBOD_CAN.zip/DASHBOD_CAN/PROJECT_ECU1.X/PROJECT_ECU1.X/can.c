#include <xc.h>
#include "can.h"
#include "clcd.h"

/* Global Variables */
unsigned char can_payload[13];

typedef enum _CanOpMode {
    e_can_op_mode_bits    = 0xE0,			/* Use this to access opmode bits */
	e_can_op_mode_normal  = 0x00,
	e_can_op_mode_sleep   = 0x20,
	e_can_op_mode_loop    = 0x40,
	e_can_op_mode_listen  = 0x60,
	e_can_op_mode_config  = 0x80
} CanOpMode;
/* Configure the CAN Module */
void init_can(void)
{
	/* CAN_TX = RB2, CAN_RX = RB3 */
	/* CAN_TX = RB2, CAN_RX = RB3 */
	TRISB2 = 0;								/* CAN TX */
	TRISB3 = 1;								/* CAN RX */

	/* Enter CAN module into config mode */
							 /* clear previous mode */
	  CAN_SET_OPERATION_MODE_NO_WAIT(e_can_op_mode_config); 
       //while((CANSTAT&0xE0)!=e_can_op_mode_config);/* set new mode */

	/* Wait untill desired mode is set */
	while (CANSTAT != 0x80);

	/* Enter CAN module into Mode 0 */
	ECANCON = 0x00;

	/* Initialize CAN Timing 8MHz */
	BRGCON1 = 0xE1;							/* 1110 0001, SJW=4, TQ, BRP 4 */
	BRGCON2 = 0x1B;							/* 0001 1011, SEG2PHTS 1 sampled once PS1=4TQ PropagationT 4TQ */
	BRGCON3 = 0x03;							/* 0000 0011, PS2, 4TQ */

	/*
	 * Enable Filters
	 * Filter 0
	 */ 

	/*
	 * Initialize Receive Filters
	 * Filter 0 = 0xFFC
	 */
	RXF0EIDH = 0x00;
	RXF0EIDL = 0x00;
	RXF0SIDH = 0x00;
	RXF0SIDL = 0x00;
    RXFCON0 = 0x01;    

	/* Enter CAN module into Loop back mode */
	CAN_SET_OPERATION_MODE_NO_WAIT(e_can_op_mode_normal);
    //while((CANSTAT&0xE0)!=e_can_op_mode_normal);

	/* Set Receive Mode for buffers */
	RXB0CON = 0x00;
}

void can_transmit(uint16_t msg_id, char *data, uint8_t len)
{
	TXB0EIDH = 0x00;		/* Extended Identifier */
	TXB0EIDL = 0x00;		/* Extended Identifier */

	/* 0x35E  0110 1011 110 */
	TXB0SIDH = msg_id;
    TXB0SIDL = 0x00;  // Only bits 7:5 used for standard ID


	TXB0DLC = 0x08;			/* Data Length Count */
	TXB0D0 = data[0];			/* DataByte 0 */
	TXB0D1 = data[1];			/* DataByte 1 */
	TXB0D2 = 0;			/* DataByte 2 */
	TXB0D3 = 0;			/* DataByte 3 */
	TXB0D4 = 0;			/* DataByte 4 */
	TXB0D5 = 0;			/* DataByte 5 */
	TXB0D6 = 0;			/* DataByte 6 */
	TXB0D7 = 0;			/* DataByte 7 */

	TXB0REQ = 1;
    
    while(TXB0REQ);
       
}
