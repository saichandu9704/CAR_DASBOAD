/*
    Project:   CAN Based Automotive Dashboard
 *  Author: 1. Vinod Kumar
 *          2. Yogesh
 *          3. Sai Chandu
 *  Description: Retrieve the values of gear changes, engine temperature, and speed, convert the received
 *              data into string format and transmit it along with specific message IDs�and�a�delay.
*/


#include <xc.h>
#include<stdio.h>
#include "sensor.h"


unsigned short get_rpm() {
    unsigned short adc_reg_val = read_adc(RPM_ADC_CHANNEL);
    float f = (5500 / 1023.0);
    return adc_reg_val * f + 1500;
}

void init_config() {
    init_can();
    init_adc();
    init_digital_keypad();
    //init_clcd();
}

void main() {
    init_config(); //Configuring the pheripherals

    unsigned int delay1 = 100,delay2=200;
    unsigned short rpm;
    unsigned char ind = 0, temp[4];

    while (1) {
        rpm = get_rpm();
        //if (delay < 50) 
        {
            for (int i = 0; i < 4; i++) {
                temp[i] = (rpm % 10) + '0';
                rpm = rpm / 10;
            }
            if (!delay1--) {
                can_transmit(RPM_MSG_ID, temp, sizeof (temp));
                delay1=100;
            }
        }

        char dir = process_indicator();
        
        //if (delay > 50 && delay < 100) 
        {
            if (!delay2--) {
                can_transmit(INDICATOR_MSG_ID, &dir, sizeof (dir));
                delay2=200;
            }
        }

//        if (delay++ == 100) {
//            delay = 0;
//        }
    }
}


