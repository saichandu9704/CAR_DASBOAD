
#ifndef SENSOR_H
#define	SENSOR_H

#include <stdint.h>
#include "digital_keypad.h"
#include "can.h"
#include "adc.h"
#include "clcd.h"
#include "msg_id.h"

#define RPM_ADC_CHANNEL 0x04


#define LED_OFF 0
#define LED_ON 1

#define RIGHT_IND_ON() (PORTB = PORTB | 0xC0)
#define RIGHT_IND_OFF() (PORTB = PORTB & ~0xC0)
#define LEFT_IND_ON() (PORTB = PORTB | 0x03)
#define LEFT_IND_OFF() (PORTB = PORTB & ~0x03)

typedef enum {
    e_ind_off,
    e_ind_left,
    e_ind_right,
    e_ind_bl
} IndicatorStatus;


void init_config(void);
void indicator_value(void);
unsigned short get_rpm();
void itoa(int val, char *str);
char process_indicator(void);

#endif	/* ECU1_SENSOR_H */

