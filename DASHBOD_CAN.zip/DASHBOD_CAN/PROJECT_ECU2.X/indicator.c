
#include "sensor.h"

char process_indicator(void)
{
    static unsigned char key=0,pre_key=0,flag=0;
    static unsigned short delay=0;

    key=read_digital_keypad(STATE_CHANGE);
    if(key!=ALL_RELEASED)
    {
        pre_key=key;
        delay=0;
        flag=0;
        PORTB=0x00;
    }
    if(pre_key==SWITCH1)
    {
        delay++;
        if(delay==500 && flag<2)
        {
            PORTB = (PORTB>>1) | (1<<1);
            delay=0;
            ++flag;
        }
        else if(delay==500 && flag<4)
        {
            PORTB = PORTB >>1;
            delay=0;
            ++flag;
        }
        if(flag>=4)
        {
            flag=0;
            RB0 = RB1 = 0;
        }  
        return 1;
    }
    else if(pre_key==SWITCH2)
    {
        delay++;
        if(delay==500 && flag<2)
        {
            PORTB = (PORTB<<1) | (1<<6);
            delay=0;
            ++flag;
        }
        else if(delay==500 && flag<4)
        {
            PORTB = PORTB<<1;
            delay=0;
            ++flag;
        }
        if(flag>=4)
        {
            flag=0;
            RB6 = RB7 = 0;
        }
        return 2;
    }
    else if(pre_key==SWITCH4)
    {
        PORTB=0x00;
        return 0;
    }
    else if(pre_key==SWITCH3)
    {
        delay++;
        if(delay==500 && flag==0)
        {
            PORTB = 0xC3;
            delay=0;
            flag=1;
        }
        else if(delay==500 && flag==1)
        {
            PORTB = 0x00;
            delay=0;
            flag=0;
        }
        return 3;
    }
}
