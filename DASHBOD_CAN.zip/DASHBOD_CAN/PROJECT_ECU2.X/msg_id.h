 #ifndef MSG_ID_H
#define	MSG_ID_H

#define SPEED_MSG_ID 0x40
#define GEAR_MSG_ID 0x05
#define RPM_MSG_ID 0x04
#define ENG_TEMP_MSG_ID 0x01
#define INDICATOR_MSG_ID 0x45

#endif	/* MSG_ID_H */

