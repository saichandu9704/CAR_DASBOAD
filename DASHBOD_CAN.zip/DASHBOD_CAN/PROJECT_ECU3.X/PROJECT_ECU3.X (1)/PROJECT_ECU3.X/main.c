/*
    Project:   CAN Based Automotive Dashboard
 *  Author: 1. Vinod Kumar
 *          2. Yogesh
 *          3. Sai Chandu
 *  Description: Retrieve the values of gear changes, engine temperature, and speed, convert the received
 *              data into string format and transmit it along with specific message IDs and a delay.
*/


#include <xc.h>
#include "message_handler.h"
#include "clcd.h"

extern unsigned char can_payload[13];

void init_config(void)
{
    init_can();
    init_clcd();
}

void main(void) {
    init_config();
    clcd_print("SPD TE GE RPM  I",LINE1(0));
    while(1)
    {
        if (can_receive())  // If a message has been received
        {
            if(can_payload[SIDH]==SPEED_MSG_ID)
            {
                handle_speed_data();
            }
            else if(can_payload[SIDH]==GEAR_MSG_ID)
            {
                handle_gear_data();
            }
            else if(can_payload[SIDH]==RPM_MSG_ID)
            {
                handle_rpm_data();
            }
            else if(can_payload[SIDH]==ENG_TEMP_MSG_ID)
            {
                handle_engine_temp_data();
            }
            else if(can_payload[SIDH]==INDICATOR_MSG_ID)
            {
                handle_indicator_data();
            }
        }
    }
    return;
}
