#ifndef MESSAGE_HANDLER_H
#define	MESSAGE_HANDLER_H

#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include <stdint.h>

#define LED_OFF 0
#define LED_ON 1

#define RIGHT_IND_ON() (PORTB = (PORTB<<1) | (1<<6))
#define RIGHT_IND_OFF() (PORTB = PORTB<<1)
#define LEFT_IND_ON() (PORTB = (PORTB>>1) | (1<<1))
#define LEFT_IND_OFF() (PORTB = PORTB >>1)

//#define RIGHT_IND_ON() (PORTB = PORTB | 0xC0)
//#define RIGHT_IND_OFF() (PORTB = PORTB & ~0xC0)
//#define LEFT_IND_ON() (PORTB = PORTB | 0x03)
//#define LEFT_IND_OFF() (PORTB = PORTB & ~0x03)

extern volatile unsigned char led_state, status;

typedef enum {
    e_ind_off,
    e_ind_left,
    e_ind_right
} IndicatorStatus;

void init_config(void);
void process_canbus_data(void);
void handle_speed_data(void);
void handle_gear_data(void);
void handle_rpm_data(void);
void handle_engine_temp_data(void);
void handle_indicator_data(void);


#endif	/* MESSAGE_HANDLER_H */

