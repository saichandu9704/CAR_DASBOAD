
#include <xc.h>
#include "message_handler.h"

extern unsigned char can_payload[13];
const char gear_chars[] = {'R', 'N', '1', '2', '3', '4', '5', '6'};

void handle_speed_data(void)
{
    for (int i = 0; i < 2; i++)
    {
        clcd_putch(can_payload[D0 + i] + '0', LINE2(0 + i));
    }
}

void handle_engine_temp_data(void)
{
    for (int i = 0; i < 2; i++)
    {
        clcd_putch(can_payload[D0 + i] + '0', LINE2(4 + i));
    }
}

void handle_gear_data(void)
{
    if (can_payload[D0] == 8) {
        clcd_print("CO", LINE2(7));
        while (1);  // Stop on collision
    } else {
        if (can_payload[D0] <= 7) {
            clcd_putch('G', LINE2(7));
            clcd_putch(gear_chars[can_payload[D0]], LINE2(8));
        }
    }
}

void handle_rpm_data(void)
{
    for (int i = 3; i >= 0; i--)
    {
        clcd_putch(can_payload[D0 + i], LINE2(13 - i));
    }
}

void handle_indicator_data(void)
{
    if(can_payload[D0]==0)
    {
        clcd_putch('O', LINE2(15));
    }
    else if(can_payload[D0]==1)
    {
        clcd_putch('L', LINE2(15));
    }
    else if(can_payload[D0]==2)
    {
        clcd_putch('R', LINE2(15));
    }
    else if(can_payload[D0]==3)
    {
        clcd_putch('H', LINE2(15));
    }
}